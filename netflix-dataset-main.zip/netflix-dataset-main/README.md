# Netflix Dataset


A small dataset from netflix data to study
